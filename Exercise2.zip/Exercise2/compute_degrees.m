function [degrees] = compute_degrees(A)
degrees = sum(A');
endfunction